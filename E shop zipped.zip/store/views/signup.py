from django.shortcuts import render,redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View



class Signup(View):
    def get(self,request):
        return render(request,'signup.html')

    def post(self,request):
        postData= request.POST
        first_name=postData.get('firstname')
        last_name=postData.get('lastname')
        phonenumber=postData.get('phonenumber')
        email=postData.get('email')
        password=postData.get('password')

            # filling form after error
        value={
            'first_name':first_name,
            'last_name':last_name,
            'phonenumber': phonenumber,
            'email':email
            }
        
            # VALIDATION
        error_message=None
        customer=Customer(
            first_name=first_name,
            last_name=last_name,
            phonenumber= phonenumber,
            email = email,
            password=password)

        error_message= self.validateCustomer(customer)
        if not error_message: 
            print(first_name,last_name,phonenumber,password)

                # for hashing password
            customer.password= make_password(customer.password)
                
            customer.register()
            return redirect('homepage')
            

        else:
            data = {
                'error':error_message,
                'values':value
            }
            return render(request,'signup.html',data)
            
            
    
    def validateCustomer(self,customer):
        error_message=None
        if(not customer.first_name):
            error_message="First name required!!!"
        elif len(customer.first_name)<3:
            error_message="Required Atleast 3 characters"
        elif(not customer.last_name):
            error_message="Last name required!!!"
        elif len(customer.last_name)<3:
            error_message="Required Atleast 3 characters"
        elif(not customer.phonenumber):
            error_message="Phone Number required!!!"
        elif len(customer.phonenumber)<9:
            error_message="Required Atleast 3 characters"
        elif(not customer.password):
            error_message="password required!!!"
        elif len(customer.password)<6:
            error_message="Required Password"
        elif len(customer.email)<11:
            error_message="Email Length should be atleast 12 character"
        elif customer.isExist():
            error_message='Email has already taken.'
            
        return error_message

